Yo les gars !
Petite template avec les esx de base
C'est une version avec ESX Legacy parfait pour le système de poids !


https://discord.gg/Xvbgdqpyye