---
id: 3
name: 'mysql_slow_query_warning'
---
Sets a limit in millisecondss, queries slower than this limit will be displayed with a warning at the specified location of
`mysql_debug_output`, see above (Default: `100`)