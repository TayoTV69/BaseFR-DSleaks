---
id: 17
name: 'localInfile'
---
Allow `LOAD DATA INFILE` to use the LOCAL modifier. (Default: `true`)