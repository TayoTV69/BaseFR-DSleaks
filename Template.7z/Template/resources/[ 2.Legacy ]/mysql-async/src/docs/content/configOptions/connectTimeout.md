---
id: 10
name: 'connectTimeout'
---
The milliseconds before a timeout occurs during the initial connection to the MySQL server. (Default: `10000`)