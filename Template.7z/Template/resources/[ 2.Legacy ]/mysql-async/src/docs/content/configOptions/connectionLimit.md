---
id: 23
name: 'connectionLimit'
---
The maximum number of connections to create at once. (Default: `10`)